import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildtitleComponent } from './childtitle.component';

describe('ChildtitleComponent', () => {
  let component: ChildtitleComponent;
  let fixture: ComponentFixture<ChildtitleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildtitleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildtitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
